package movement;

public interface moveaction {

	public void autojump();
	public void leftmetjump();
	public void rightmetjump();
	public void superjump();
	public void goleft();
	public void goright();
	public void fall();
	
	
	
	
}
