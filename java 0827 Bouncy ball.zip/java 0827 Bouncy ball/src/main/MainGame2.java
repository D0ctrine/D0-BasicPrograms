package main;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;

import map.Block_Som;
import map.G1;
import map.N2;
import map.N3;
import map.N6;
import map.N9;
import map.O6;
import map.blockH;
import map.blockW;
import map.bomb;
import map.left;

public class MainGame2 extends JFrame implements KeyListener {

	myball ball = myball.getInstance();
	MyCanvas mc = new MyCanvas();
	JLabel title = new JLabel("공튀기기 게임 ^^");
	blockW box1 = new blockW(10, 10); // upside
	blockH box2 = new blockH(10, 40); // left side
	Block_Som somBox1 = new Block_Som(130, 215); // crush downside
	Block_Som somBox2 = new Block_Som(160, 215);
	Block_Som somBox3 = new Block_Som(190, 215);
	Block_Som somBox4 = new Block_Som(220, 215);
	Block_Som somBox5 = new Block_Som(250, 215);
	N3 box4 = new N3(40, 215); // second-fir downside
	O6 Right_side = new O6(446, 40); // <<
	N9 box3 = new N9(174, 100); // first downside
	N2 box5 = new N2(280, 215); // second-third downside
	N6 box6 = new N6(293, 301); // last downside
	bomb bbox = new bomb(385, 240);
	G1 tbox11 = new G1(70, 251);
	left lbox = new left(354, 271);
	boolean sombox1 = true;
	boolean sombox2 = true;
	boolean sombox3 = true;
	boolean sombox4 = true;
	boolean sombox5 = true;
	boolean keypress = false;
	int result = -1;
	int keyInfo[] = new int[] { -1, -1, -1, -1 }; // 키가 눌린 정보
	int level = 1;
	int fontsize = 0;

	MainGame2() {
		ball.setBall_x(425);
		ball.setBall_y(65);
		ball.setGo_up(53);
		this.setBounds(100, 100, 520, 400);
		this.setLayout(new BorderLayout());
		this.add(mc, "Center");
		this.add(title, "South");
		this.setVisible(true);
		this.addKeyListener(this);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		key();
	}

	public void crashbox() {
		if (sombox1) {
			if (somBox1.Downstop()) {
				somBox1.setIc("");
				sombox1 = false;
			}
		}
		if (sombox2) {
			if (somBox2.Downstop()) {
				somBox2.setIc("");
				sombox2 = false;
			}
		}
		if (sombox3) {
			if (somBox3.Downstop()) {
				somBox3.setIc("");
				sombox3 = false;
			}
		}
		if (sombox4) {
			if (somBox4.Downstop()) {
				somBox4.setIc("");
				sombox4 = false;
			}
		}
		if (sombox5) {
			if (somBox5.Downstop()) {
				somBox5.setIc("");
				sombox5 = false;
			}
		}
	}

	private void key() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while (true) {
					try {
						if (ball != null) {
							if (ball.getBall_y() > 398) {
								ball = null;
							}
							// 좌우
							if (box2.Leftstop()) { // 왼쪽에서 멈추기
								keyInfo[0] = -1;
								ball.setLeft(true);
							}
							if (Right_side.Rightstop()) {
								keyInfo[2] = -1;
							}

							if (box3.Rightstop()) {
								keyInfo[2] = -1;
							}
							if (box4.Leftstop()) {
								keyInfo[0] = -1;
							}
							if (box4.Upstop()) {
								ball.setNojump(false);
								keyInfo[0] = -1;
							}
							if (box5.Leftstop()) {
								keyInfo[0] = -1;
							}
							if (box5.Rightstop()) {
								keyInfo[2] = -1;
							}
							if (box6.Rightstop()) {
								keyInfo[2] = -1;
							}

							if (bbox.Downstop()) {
								bbox.setIc("./img/폭발.png");
								while (bbox.getWidth() < 100) {
										bbox.setX(343);
										bbox.setY(203);
										bbox.setWidth();
								}
							
								ball = null;
							}

							if (box1.Upstop()) {
								ball.setJump(false);
							}
							keyAction();
							if (tbox11.Leftstop()) {
								result = 1;
								ball = null;
							}
							if (tbox11.Rightstop()) {
								result = 1;
								ball = null;
							}
							if (tbox11.Leftstop()) {
								result = 1;
								ball = null;
							}
							if (tbox11.Upstop()) {
								result = 1;
								ball = null;
							}
							box3.Downstop();
							box4.Downstop();
							box5.Downstop();
							// 좌로 쭉가기
							lbox.Leftstop();
							lbox.Downstop();

							if (!ball.isLeft()) {
								if (keypress) {
									ball.setLeft(true);
									ball.setdownFlag(true);
								} else {
									ball.moveBall_x(-2);
								}
							}
							crashbox();

							// 상하
							// 박스 위에서 멈추고 뛸때
							if (box6.Downstop()) {
								ball.fall();
							} else {
								ball.autojump();
							}
						}
						Thread.sleep(15);
						mc.repaint();
					} catch (Exception e) {
						if (result == -1) {
							result = 0;
						}
					}
				}
			}
		}).start();
	}

	private void keyAction() {
		if (ball.getBall_x() != 0) {

			if (keyInfo[0] == 1) {
				ball.moveBall_x(-2);

			}

			if (keyInfo[2] == 1) {
				ball.moveBall_x(2);

			}

		}
	}

	class MyCanvas extends Canvas {
		MyCanvas() {
			ball.fall();
			ball.autojump();
			this.setSize(300, 400);
			this.setBackground(Color.BLACK);
		}

		@Override
		public void paint(Graphics g) {
			// TODO Auto-generated method stub
			Image img = createImage(520, 400);
			Graphics pen = img.getGraphics();

			pen.setColor(Color.white);

			if (ball != null)
				pen.fillRoundRect(ball.getBall_x(), ball.getBall_y(), 8, 8, 8, 8);

			pen.drawImage(box1.getIc(), box1.getX(), box1.getY(), box1.getWidth(), box1.getHeight(), this);
			pen.drawImage(box2.getIc(), box2.getX(), box2.getY(), box2.getWidth(), box2.getHeight(), this);

			if (sombox1) {
				pen.drawImage(somBox1.getIc(), somBox1.getX(), somBox1.getY(), somBox1.getWidth(), somBox1.getHeight(),
						this);
			}
			if (sombox2) {
				pen.drawImage(somBox2.getIc(), somBox2.getX(), somBox2.getY(), somBox2.getWidth(), somBox2.getHeight(),
						this);
			}
			if (sombox3) {
				pen.drawImage(somBox3.getIc(), somBox3.getX(), somBox3.getY(), somBox3.getWidth(), somBox3.getHeight(),
						this);
			}
			if (sombox4) {
				pen.drawImage(somBox4.getIc(), somBox4.getX(), somBox4.getY(), somBox4.getWidth(), somBox4.getHeight(),
						this);
			}
			if (sombox5) {
				pen.drawImage(somBox5.getIc(), somBox5.getX(), somBox5.getY(), somBox5.getWidth(), somBox5.getHeight(),
						this);
			}
			pen.drawImage(box4.getIc(), box4.getX(), box4.getY(), box4.getWidth(), box4.getHeight(), this);
			pen.drawImage(lbox.getIc(), lbox.getX(), lbox.getY(), lbox.getWidth(), lbox.getHeight(), this);

			pen.drawImage(Right_side.getIc(), Right_side.getX(), Right_side.getY(), Right_side.getWidth(),
					Right_side.getHeight(), this);

			pen.drawImage(box3.getIc(), box3.getX(), box3.getY(), box3.getWidth(), box3.getHeight(), this);

			pen.drawImage(box5.getIc(), box5.getX(), box5.getY(), box5.getWidth(), box5.getHeight(), this);

			pen.drawImage(box6.getIc(), box6.getX(), box6.getY(), box6.getWidth(), box6.getHeight(), this);
			pen.drawImage(tbox11.getIc(), tbox11.getX(), tbox11.getY(), tbox11.getWidth(), tbox11.getHeight(), this);
			pen.drawImage(bbox.getIc(), bbox.getX(), bbox.getY(), bbox.getWidth(), bbox.getHeight(), this);
			if (result == 1) {
				if (fontsize < 30) {
					fontsize++;
				}
				pen.setColor(Color.GREEN);
				pen.setFont(new Font("궁서", Font.BOLD, (30 + fontsize)));// 폰트설정
				pen.drawString("Level Up", 100, 140);
			} else if (result == 0) {
				if (fontsize < 30) {
					fontsize++;
				}
				pen.setColor(Color.red);
				pen.setFont(new Font("궁서", Font.BOLD, (30 + fontsize)));// 폰트설정
				pen.drawString("GameOver", 100, 140);
			}
			g.drawImage(img, 0, 0, this);
		}

		@Override
		public void update(Graphics g) {
			paint(g);
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.getKeyCode() == 37) {
			keyInfo[0] = 1;

		} else if (e.getKeyCode() == 39) {
			keyInfo[2] = 1;

		}

	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
//		
		keyInfo[0] = -1;
		keyInfo[2] = -1;

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}

}