package main;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;

import map.G2;
import map.N2;
import map.N5;
import map.O2;
import map.O4;
import map.O6;
import map.blockH;
import map.blockW;

public class MainGame extends JFrame implements KeyListener {

	myball ball = myball.getInstance();
	MyCanvas mc = new MyCanvas();
	JLabel title = new JLabel("공튀기기 게임 ^^");
	O6 box5 = new O6(475, 10);
	N5 tbox3 = new N5(10,300);
	O2 tbox4 = new O2(160,240);
	O4 tbox6 = new O4 (220, 180);
	O6 tbox8 = new O6(280,120);
	N2 tbox9 = new N2(310,300);
	N2 tbox10 = new N2 (445, 300);
	G2 tbox11 = new G2(475,220);
	blockW box1 = new blockW(10, 10);
	blockH box2 = new blockH(10, 10);
	int result = -1;
	int keyInfo[] = new int[] { -1, -1, -1, -1 }; // 키가 눌린 정보
	int level = 1;
	int fontsize = 0;

	MainGame() {

		this.setBounds(100, 100, 520, 400);
		this.setLayout(new BorderLayout());
		this.add(mc, "Center");
		this.add(title, "South");
		this.setVisible(true);
		this.addKeyListener(this);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		key();
	}

public void map(int i) {
	
}
	private void key() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while (true) {
					try {
						if (ball != null) {
							if (ball.getBall_y() > 398) {
								ball = null;
							}
							// 좌우
							if (box2.Leftstop()) { // 왼쪽에서 멈추기
								keyInfo[0] = -1;
							}
							if(tbox4.Leftstop()) {
								keyInfo[0] = -1;
							}
							if(tbox4.Rightstop()) {
								keyInfo[2]=-1;
							}
							
							if(tbox6.Leftstop()) {
								keyInfo[0] = -1;
							}
							if (tbox6.Rightstop()) {
								keyInfo[2] = -1;
							}
							if(tbox8.Leftstop()) {
								keyInfo[0] = -1;
							}
							if (tbox8.Rightstop()) {
								keyInfo[2] = -1;
							}
							if(tbox11.Rightstop()) {
								result = 1;
								ball = null;
							}
							
							if(tbox11.Upstop()) {
								result = 1;
								ball = null;
							}
							if(box1.Upstop()) {
								ball.setJump(false);
							}
							keyAction();
							
							
							tbox4.Downstop();
							tbox6.Downstop();
							tbox8.Downstop();
							tbox9.Downstop();
							tbox10.Downstop();
							
							
							// 상하
							// 박스 위에서 멈추고 뛸때
							if(tbox3.Downstop()) {
								ball.fall();
							}else{
								ball.autojump();
							}
						}
						Thread.sleep(15);
						mc.repaint();
					} catch (Exception e) {
						if(result==-1) {
							result = 0;
						}
					}
				}
			}
		}).start();
	}

	private void keyAction() {
		if (ball.getBall_x() != 0) {

			if (keyInfo[0] == 1) {
				ball.moveBall_x(-2);
			}

			if (keyInfo[2] == 1) {
				ball.moveBall_x(2);
			}

		}
	}

	class MyCanvas extends Canvas {
		MyCanvas() {
			ball.fall();
			ball.autojump();
			this.setSize(300, 400);
			this.setBackground(Color.BLACK);
		}

		@Override
		public void paint(Graphics g) {
			// TODO Auto-generated method stub
			Image img = createImage(520,400);
			Graphics pen = img.getGraphics();
			
			pen.setColor(Color.white);
			
			if (ball != null)
				pen.fillRoundRect(ball.getBall_x(), ball.getBall_y(), 8, 8, 8, 8);

			pen.drawImage(box1.getIc(), box1.getX(), box1.getY(), box1.getWidth(),box1.getHeight(), this);
			pen.drawImage(box2.getIc(), box2.getX(),box2.getY(), box2.getWidth(), box2.getHeight(), this);
			pen.drawImage(box5.getIc(),box5.getX() ,box5.getY(),box5.getWidth(),box5.getHeight(),this);
			pen.drawImage(tbox3.getIc(), tbox3.getX(), tbox3.getY(), tbox3.getWidth(), tbox3.getHeight(), this);
			
			pen.drawImage(tbox4.getIc(), tbox4.getX(), tbox4.getY(), tbox4.getWidth(), tbox4.getHeight(), this);
			
			pen.drawImage(tbox6.getIc(), tbox6.getX(), tbox6.getY(), tbox6.getWidth(), tbox6.getHeight(), this);
			
			pen.drawImage(tbox8.getIc(), tbox8.getX(), tbox8.getY(), tbox8.getWidth(), tbox8.getHeight(), this);
			
			pen.drawImage(tbox9.getIc(), tbox9.getX(), tbox9.getY(), tbox9.getWidth(), tbox9.getHeight(), this);
			
			pen.drawImage(tbox10.getIc(), tbox10.getX(), tbox10.getY(), tbox10.getWidth(), tbox10.getHeight(), this);
			
			pen.drawImage(tbox11.getIc(), tbox11.getX(), tbox11.getY(), tbox11.getWidth(), tbox11.getHeight(), this);
			
			if(result==1) {
				if(fontsize<30) {
					fontsize++;
				}
				pen.setColor(Color.GREEN);
				pen.setFont(new Font("궁서", Font.BOLD, (30+fontsize)));// 폰트설정
				pen.drawString("Level Up", 100, 140);
			}else if(result==0){
				if(fontsize<30) {
					fontsize++;
				}
				pen.setColor(Color.red);
				pen.setFont(new Font("궁서", Font.BOLD, (30+fontsize)));// 폰트설정
				pen.drawString("GameOver", 100, 140);
			}
			g.drawImage(img, 0, 0, this);
		}

		@Override
		public void update(Graphics g) {
			paint(g);
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if (e.getKeyCode() == 37) {
			keyInfo[0] = 1;
		} else if (e.getKeyCode() == 39) {
			keyInfo[2] = 1;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
//		
		keyInfo[0] = -1;
		keyInfo[2] = -1;

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

}