package main;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		new MainGame();
//		new MainGame2();
		new MainGame3();
	}
 
}
