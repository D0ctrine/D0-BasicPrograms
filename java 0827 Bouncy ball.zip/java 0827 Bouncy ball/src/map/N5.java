package map;

import main.myball;

public class N5 extends block{

	public N5(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/맵박스5.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean N5 = false;
	public boolean isN5() {
		return N5;
	}

	public void setN5(boolean N5) {
		this.N5 = N5;
	}



}
