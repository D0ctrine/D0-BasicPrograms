package map;

import main.myball;

public class N3 extends block{

	public N3(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/맵박스3.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean N3 = false;
	public boolean isN3() {
		return N3;
	}

	public void setN3(boolean N3) {
		this.N3 = N3;
	}

}
