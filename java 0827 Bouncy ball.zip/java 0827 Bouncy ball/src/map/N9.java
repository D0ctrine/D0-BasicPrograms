package map;

import main.myball;

public class N9 extends block{

	public N9(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/맵박스9.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean N9 = false;
	public boolean isN9() {
		return N9;
	}

	public void setN9(boolean N9) {
		this.N9 = N9;
	}

}
