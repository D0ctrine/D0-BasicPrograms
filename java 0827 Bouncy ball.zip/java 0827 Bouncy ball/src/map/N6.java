package map;

import main.myball;

public class N6 extends block{

	public N6(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/맵박스6.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean N6 = false;
	public boolean isN6() {
		return N6;
	}

	public void setN6(boolean N6) {
		this.N6 = N6;
	}

}
