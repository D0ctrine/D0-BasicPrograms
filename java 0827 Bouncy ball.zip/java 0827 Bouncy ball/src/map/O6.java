package map;

import main.myball;

public class O6 extends block{

	public O6(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/벽2.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean O6 = false;
	public boolean isO6() {
		return O6;
	}

	public void setO6(boolean O6) {
		this.O6 = O6;
	}

	
	
	

}
