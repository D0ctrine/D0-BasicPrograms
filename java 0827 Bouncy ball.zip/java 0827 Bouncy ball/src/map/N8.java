package map;

import main.myball;

public class N8 extends block{

	public N8(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/벽8.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean N8 = false;
	public boolean isN8() {
		return N8;
	}

	public void setN8(boolean N8) {
		this.N8 = N8;
	}

}
