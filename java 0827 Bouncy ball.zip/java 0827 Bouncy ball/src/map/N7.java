package map;

import main.myball;

public class N7 extends block{

	public N7(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/맵박스7.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean N7 = false;
	public boolean isN7() {
		return N7;
	}

	public void setN7(boolean N7) {
		this.N7 = N7;
	}

	

}
