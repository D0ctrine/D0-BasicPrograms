package map;

public class N1 extends block{

	public N1(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/맵박스1.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));		
	}


	

}