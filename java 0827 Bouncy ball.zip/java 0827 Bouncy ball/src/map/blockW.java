package map;

import java.awt.Image;

import javax.swing.ImageIcon;

import main.myball;

public class blockW extends block {

	myball ball = myball.getInstance();
	boolean flag = false;
	public blockW(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/가로.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	boolean blockW = false;
	public boolean isBlockW() {
		return blockW;
	}

	public void setBlockW(boolean blockW) {
		this.blockW = blockW;
	}

	
}
