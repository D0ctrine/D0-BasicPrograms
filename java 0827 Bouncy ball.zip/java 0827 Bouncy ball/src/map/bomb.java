package map;

import main.myball;

public class bomb extends block{

	public bomb(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/맵폭발.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean G1 = false;
	public boolean isG1() {
		return G1;
	}
	public boolean Downstop() { // 떨어지는거 스탑
		boolean flag = false;
		if ((ball.getBall_y() + 8) > (getY() - 2) && (getY() + getHeight()) > (ball.getBall_y() + 8)) {
		if ((ball.getBall_x() + 8) > (getX() + 2) && (getX() + getWidth()) > ball.getBall_x()) {
				ball.setdownFlag(false);
				flag = true;
				
				}
			}
		
		return flag;
	}
	public void setWidth() {
		width+=10;
		height+=10;
	}

	public void setO6(boolean G1) {
		this.G1 = G1;
	}

	

}
