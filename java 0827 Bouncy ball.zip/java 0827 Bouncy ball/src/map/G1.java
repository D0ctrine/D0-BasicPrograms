package map;

import main.myball;

public class G1 extends block{

	public G1(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/clear1.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean G1 = false;
	public boolean isG1() {
		return G1;
	}

	public void setO6(boolean G1) {
		this.G1 = G1;
	}

	

}
