package map;

import main.myball;

public class O5 extends block{

	public O5(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/벽3.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean O5 = false;
	public boolean isO5() {
		return O5;
	}

	public void setO5(boolean O5) {
		this.O5 = O5;
	}

	

}
