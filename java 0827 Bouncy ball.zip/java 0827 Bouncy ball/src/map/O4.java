package map;

import main.myball;

public class O4 extends block{

	public O4(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/벽4.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean 테스트 = false;
	public boolean is테스트() {
		return 테스트;
	}

	public void set테스트(boolean 테스트) {
		this.테스트 = 테스트;
	}


}
