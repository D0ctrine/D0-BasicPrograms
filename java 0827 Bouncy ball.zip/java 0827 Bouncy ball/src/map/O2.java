package map;

import main.myball;
import map.block;

public class O2 extends block{

	public O2(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/벽6.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean o1 = false;
	public boolean isO1() {
		return o1;
	}

	public void setO1(boolean o1) {
		this.o1 = o1;
	}

	
	

}