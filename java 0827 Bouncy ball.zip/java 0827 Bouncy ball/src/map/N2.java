package map;

import main.myball;

public class N2 extends block{

	public N2(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/맵박스2.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean N2 = false;
	public boolean isN2() {
		return N2;
	}

	public void setN2(boolean N2) {
		this.N2 = N2;
	}


	
	

}
