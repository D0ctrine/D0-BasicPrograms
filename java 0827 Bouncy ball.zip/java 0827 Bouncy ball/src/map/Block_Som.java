package map;

import main.myball;

public class Block_Som extends block{

	public Block_Som(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/som.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	public boolean Downstop() { // 떨어지는거 스탑
		boolean flag = false;
		if ((ball.getBall_y() + 8) > (getY() - 2) && (getY() + 2) > (ball.getBall_y() + 8)) {
		if ((ball.getBall_x() + 8) > (getX() + 2) && (getX() + getWidth()) > ball.getBall_x()) {
				ball.setStartjump(getY());
				flag = true;
				ball.setdownFlag(false);
			}
		}
		return flag;
	}
	boolean Bl_som = false;
	public boolean isBl_som() {
		return Bl_som;
	}

	public void setBl_som(boolean Bl_som) {
		this.Bl_som = Bl_som;
	}

	

}
