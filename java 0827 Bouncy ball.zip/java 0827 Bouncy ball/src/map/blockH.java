package map;

import java.awt.Image;

import javax.swing.ImageIcon;

import main.myball;

public class blockH extends block {

	myball ball = myball.getInstance();
	public blockH(int x,int y){
		setX(x);
		setY(y);
		setIc("./img/세로.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}



	
}
