package map;

import main.myball;

public class left extends block{

	public left(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/맵좌로.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean G2 = false;
	public boolean Downstop() { // 떨어지는거 스탑
		boolean flag = false;
		if ((ball.getBall_y() + 8) > (getY() - 2) && (getY() + getHeight()) > (ball.getBall_y() + 8)) {
		if ((ball.getBall_x() + 8) > (getX() + 2) && (getX() + getWidth()) > ball.getBall_x()) {
				ball.setdownFlag(false);
				ball.setLeft(false);
				ball.setBall_y(getY()+getHeight()/2);
			}
		}
		return flag;
	}
	public boolean isG2() {
		return G2;
	}

	public void setO6(boolean G2) {
		this.G2 = G2;
	}


}