package map;

import java.awt.Image;

import javax.swing.ImageIcon;

import main.myball;

abstract public class block {
	int x;
	int y;
	Image ic = new ImageIcon("./img/box.jpg").getImage();
	int height = ic.getHeight(null);
	int width = ic.getWidth(null);
	myball ball = myball.getInstance();

	public boolean Downstop() { // 떨어지는거 스탑
		
		if ((ball.getBall_y() + 8) > (getY() - 2) && (getY() + 2) > (ball.getBall_y() + 8)) {
		if ((ball.getBall_x() + 8) > (getX() + 2) && (getX() + getWidth()) > ball.getBall_x()) {
				ball.setStartjump(getY());
				ball.setdownFlag(false);
			}
		}
		return ball.getdownFlag();
	}

	public boolean Leftstop() { // 왼쪽으로 가는거 막기
		boolean flag = false;
		if (ball.getBall_x() < (getX() + getWidth() + 2) && ball.getBall_x() > (getX() + getWidth() - 2)) {
			if (ball.getBall_y() > getY() - 2 && ball.getBall_y() < (getY() + getHeight())) {
				flag = true;
			}
		}
		return flag;
	}

	public boolean Rightstop() { // 오른쪽으로 가는거 막기
		boolean flag = false;
		if ((ball.getBall_x() + 8) < (getX() + 2) && (ball.getBall_x() + 8) > (getX() - 2)) {
			if(ball.getBall_y() >= (getY() - 4) && ball.getBall_y() < (getY()+getHeight()))
			flag = true;
		}
		return flag;
	}

	public boolean Upstop() { // 위로 박치기
		boolean flag = false;
		if (ball.getBall_y() < (getY() + getHeight() + 2) && ball.getBall_y() > (getY() + getHeight() - 2)) {
			if ((ball.getBall_x() + 8) > getX() && ball.getBall_x() < (getX() + getWidth())) {
				flag = true;
			}
		}
		return flag;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getWidth() {
		return width;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getHeight() {
		return height;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public Image getIc() {
		return ic;
	}

	public void setIc(String ic) {
		this.ic = new ImageIcon(ic).getImage();
	}

	public void setX(int x) {
		this.x = x;
	}

	public void setY(int y) {
		this.y = y;
	}
}