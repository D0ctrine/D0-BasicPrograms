package map;

import main.myball;

public class G2 extends block{

	public G2(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/clear2.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean G2 = false;
	public boolean isG2() {
		return G2;
	}

	public void setO6(boolean G2) {
		this.G2 = G2;
	}


}
