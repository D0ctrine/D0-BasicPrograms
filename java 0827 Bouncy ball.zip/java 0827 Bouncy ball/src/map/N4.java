package map;

import main.myball;

public class N4 extends block{

	public N4(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/맵박스4.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}
	myball ball = myball.getInstance();
	boolean N4 = false;
	public boolean isN4() {
		return N4;
	}

	public void setN4(boolean N4) {
		this.N4 = N4;
	}



}
