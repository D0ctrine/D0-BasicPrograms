package map;

public class O3 extends block{

	public O3(int x, int y) {
		setX(x);
		setY(y);
		setIc("./img/벽5.png");
		setHeight(getIc().getHeight(null));
		setWidth(getIc().getWidth(null));
	}

	

}